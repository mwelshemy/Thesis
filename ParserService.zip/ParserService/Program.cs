﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;
using System.Text.RegularExpressions;

class Program {
    static Dictionary<string, object> metadata = new Dictionary<string, object>(); // In-memory store

    static void Main(string[] args) {
        // === Step 1: Pick the file to parse ===
        string filePath = "UserController.cs"; 
        string code = File.ReadAllText(filePath);
        string extension = Path.GetExtension(filePath);

        object output;

        // === Step 2: Choose parser based on file extension ===
        if (extension == ".cs") {
            output = ParseCSharp(filePath, code);
        }
        else if (extension == ".py") {
            output = new {
                file = Path.GetFileName(filePath),
                functions = ParsePython(code) // placeholder, will be updated later
            };
        }
        else if (extension == ".js") {
            output = new {
                file = Path.GetFileName(filePath),
                functions = ParseJavaScript(code) // placeholder, will be updated later
            };
        }
        else {
            output = new {
                file = Path.GetFileName(filePath),
                error = "Unsupported file type"
            };
        }

        // === Step 3: Store metadata in Dictionary ===
        metadata[Path.GetFileName(filePath)] = output;

        // === Step 4: Print JSON to console and save to file ===
        Console.WriteLine(JsonSerializer.Serialize(output, new JsonSerializerOptions { WriteIndented = true }));
        File.WriteAllText("output.json", JsonSerializer.Serialize(output, new JsonSerializerOptions { WriteIndented = true }));

        // Demo: show what’s inside metadata dictionary
        Console.WriteLine("\n=== Metadata Dictionary ===");
        foreach (var kv in metadata) {
            Console.WriteLine($"{kv.Key} → {JsonSerializer.Serialize(kv.Value)}");
        }
    }

    // --- C# Parser (Roslyn) ---
    static object ParseCSharp(string filePath, string code) {
        var tree = CSharpSyntaxTree.ParseText(code);
        var root = tree.GetRoot();
        var text = tree.GetText();

        // Collect structured function info
        var functions = root.DescendantNodes().OfType<MethodDeclarationSyntax>()
            .Select(m => new {
                FunctionName = m.Identifier.Text,
                FunctionLanguage = "C#",
                FunctionCode = m.ToFullString().Trim(),
                FunctionFilePath = filePath,
                FunctionStartLine = text.Lines.GetLineFromPosition(m.Span.Start).LineNumber + 1,
                FunctionEndLine = text.Lines.GetLineFromPosition(m.Span.End).LineNumber + 1
            })
            .ToList();

        return new {
            file = Path.GetFileName(filePath),
            functions = functions
        };
    }

    // --- Python Parser (minimal, will refine later) ---
    static List<string> ParsePython(string code) {
        var matches = Regex.Matches(code, @"def\s+(\w+)\s*\(");
        return matches.Select(m => m.Groups[1].Value).ToList();
    }

    // --- JavaScript Parser (minimal, will refine later) ---
    static List<string> ParseJavaScript(string code) {
        var matches = Regex.Matches(code, @"function\s+(\w+)\s*\(");
        return matches.Select(m => m.Groups[1].Value).ToList();
    }
}
